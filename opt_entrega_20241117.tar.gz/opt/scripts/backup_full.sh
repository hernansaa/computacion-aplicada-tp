#!/bin/bash

FECHA=$(date +%Y%m%d)
DIRECTORIOS_ORIGEN="${@:2}"
DIRECTORIO_DESTINO="${1}"


# Chequea que el directorio de destino exista.

check_destino(){
	if [ ! -d "$DIRECTORIO_DESTINO" ]; then
		echo "El directorio de destino: '$DIRECTORIO_DESTINO' NO EXISTE!!. "
		exit 1
	else
		echo "El directorio de destino: '$DIRECTORIO_DESTINO)' existe."
	fi
}


# Chequea que los directorios de origen existan y crea los comprimidos de cada directorio
# de origen.

check_origen(){
	for DIRECTORIO in $DIRECTORIOS_ORIGEN; do
		if [ ! -d "$DIRECTORIO" ]; then
			echo "El directorio de origen: '$DIRECTORIO' NO EXISTE!!. "
			exit 1
		else
			echo "El directorio de origen: '$DIRECTORIO' existe."
			echo "El nuevo destino sera '$DIRECTORIO_DESTINO$DIRECTORIO'"
			echo "----------------------------------"
		fi
		echo "-----------------------"	
		tar -czvf "$DIRECTORIO_DESTINO/$(basename "$DIRECTORIO")_bkp_$FECHA.tar.gz" -C "$(dirname "$DIRECTORIO")" "$(basename "$DIRECTORIO")"		
		echo "-----------------------"
	done
}


# PROGRAMA PRINCIPAL

case ${1} in
	-h)
		echo "1er arg: directorio destino, resto args: directorios origen"
		;;
	*)
		check_origen
		check_destino
		;;
esac




